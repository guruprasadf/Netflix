import React  from 'react';
import RouterList from './Route/Route'

class App extends React.Component{
      render(){
        return (<RouterList />)
	}
}
export default App;
